# Memory Game Project

## Table of Contents

* [Instruction](Instruction)
* [Dependency](#Dependency)


## Instruction
Open the _index.html_ file in the browser.
## Dependency
[Bootstrap](https://getbootstrap.com/docs/4.0/getting-started/download/)  (for the end modal)
